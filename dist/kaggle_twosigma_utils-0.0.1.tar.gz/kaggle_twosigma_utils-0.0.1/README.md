This is library with some basic functions for https://www.kaggle.com/c/two-sigma-financial-news competitons. 
Included functions:
- train dataset reading
- cross-validation
- building submission